#!/usr/bin/env bash
# Convenience wrapper — runs the offline demo against bundled sample configs.
# For real use, see README (export_configs.py or --target panorama/firewall).
set -e
python3 -m cis_panos.audit --offline sample_configs/ --out reports/ "$@"

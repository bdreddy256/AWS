#!/usr/bin/env python3
"""
CIS PAN-OS Compliance Audit Tool  (dependency-free)
===================================================
Pulls running config from Panorama or a firewall (read-only), evaluates it
against CIS PAN-OS benchmark checks, and produces timestamped CSV + HTML + PDF
reports — evidence for #54 (scan), #86 (annual review), #87 (non-compliant pop).

ZERO EXTERNAL DEPENDENCIES. Pure Python standard library. No pip install.
Requires Python 3.8+ (already on most systems).

CONNECTION MODES
  --offline <file-or-dir>       Evaluate exported config XML. No network.
                                (Recommended for banks — no live prod scan.)
  --target firewall --host H --apikey K
                                Pull one firewall's running config directly.
  --target panorama --host H --apikey K
                                Enumerate + pull every managed device via Panorama.

READ-ONLY: only issues 'show config' API calls. Never commits.

GET A READ-ONLY API KEY (use a superreader / read-only admin):
  curl -k "https://<host>/api/?type=keygen&user=<user>&password=<pass>"

USAGE
  python -m cis_panos.audit --offline ./configs/ --out reports/
  python -m cis_panos.audit --target firewall --host 10.0.0.1 --apikey "$PANKEY"
  python -m cis_panos.audit --target panorama --host 10.0.0.9 --apikey "$PANKEY"

Validate check logic against your CIS PDF before using as sole audit evidence.
"""

import argparse
import csv
import datetime
import glob
import html
import os
import ssl
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

# Support both `python -m cis_panos.audit` and `python cis_panos/audit.py`
try:
    from .checks.cis_checks import CHECKS
    from .pdf_writer import build_pdf
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from checks.cis_checks import CHECKS
    from pdf_writer import build_pdf


# ----------------------------- API layer -----------------------------

def _api_get(host, params, verify_tls=False, timeout=30):
    ctx = ssl.create_default_context()
    if not verify_tls:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    url = f"https://{host}/api/?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, context=ctx, timeout=timeout) as r:
        data = r.read()
    root = ET.fromstring(data)
    if root.get("status") != "success":
        msg = root.findtext(".//msg") or "unknown API error"
        raise RuntimeError(f"API error from {host}: {msg}")
    return root


def get_firewall_running_config(host, apikey, verify_tls=False):
    root = _api_get(host, {"type": "config", "action": "show",
                           "xpath": "/config", "key": apikey}, verify_tls)
    cfg = root.find(".//result/config")
    if cfg is None:
        raise RuntimeError(f"No running config returned from {host}")
    return cfg


def list_panorama_devices(host, apikey, verify_tls=False):
    root = _api_get(host, {
        "type": "op",
        "cmd": "<show><devices><connected></connected></devices></show>",
        "key": apikey}, verify_tls)
    devs = []
    for e in root.findall(".//devices/entry"):
        serial = e.get("name") or e.findtext("serial") or "unknown"
        hostname = e.findtext("hostname") or serial
        devs.append((serial, hostname))
    return devs


def get_device_config_via_panorama(host, apikey, serial, verify_tls=False):
    root = _api_get(host, {"type": "config", "action": "show", "xpath": "/config",
                           "target": serial, "key": apikey}, verify_tls)
    cfg = root.find(".//result/config")
    if cfg is None:
        raise RuntimeError(f"No config for device {serial} via Panorama")
    return cfg


# ----------------------------- evaluation -----------------------------

def run_checks(config_root, device_label):
    rows = []
    for chk in CHECKS:
        try:
            result, evidence = chk["fn"](config_root)
        except Exception as e:
            result, evidence = "ERROR", f"check exception: {e}"
        rows.append({"device": device_label, "id": chk["id"],
                     "title": chk["title"], "severity": chk["severity"],
                     "result": result, "evidence": evidence})
    return rows


def load_offline_configs(path):
    if os.path.isdir(path):
        files = sorted(glob.glob(os.path.join(path, "*.xml")))
    elif os.path.isfile(path):
        files = [path]
    else:
        raise SystemExit(f"Path not found: {path}")
    if not files:
        raise SystemExit(f"No .xml config files found at: {path}")
    out = []
    for f in files:
        root = ET.parse(f).getroot()
        cfg = root if root.tag == "config" else root.find(".//config")
        if cfg is None:
            print(f"  ! skipping {f}: no <config> element", file=sys.stderr)
            continue
        label = os.path.splitext(os.path.basename(f))[0]
        out.append((label, cfg))
    return out


# ----------------------------- reporting -----------------------------

RESULT_ORDER = {"FAIL": 0, "ERROR": 1, "MANUAL": 2, "PASS": 3}


def _sorted(rows):
    return sorted(rows, key=lambda x: (x["device"],
                  RESULT_ORDER.get(x["result"], 9), x["id"]))


def _summary(rows):
    s = {"PASS": 0, "FAIL": 0, "MANUAL": 0, "ERROR": 0}
    for r in rows:
        s[r["result"]] = s.get(r["result"], 0) + 1
    return s


def write_csv(rows, out_dir, ts):
    p = os.path.join(out_dir, f"cis_panos_report_{ts}.csv")
    with open(p, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["device", "id", "title",
                           "severity", "result", "evidence"])
        w.writeheader()
        for r in _sorted(rows):
            w.writerow(r)
    return p


def write_html(rows, out_dir, ts, meta):
    p = os.path.join(out_dir, f"cis_panos_report_{ts}.html")
    s = _summary(rows)
    devices = sorted({r["device"] for r in rows})
    color = {"PASS": "#1a7f37", "FAIL": "#cf222e",
             "MANUAL": "#9a6700", "ERROR": "#8250df"}
    b = [f"""<!doctype html><html><head><meta charset="utf-8">
<title>CIS PAN-OS Compliance Report {html.escape(ts)}</title><style>
 body{{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:24px;color:#1c2128}}
 h1{{font-size:20px;margin:0 0 4px}} .meta{{color:#57606a;font-size:13px;margin-bottom:16px}}
 .cards{{display:flex;gap:12px;margin:16px 0}}
 .card{{border:1px solid #d0d7de;border-radius:8px;padding:10px 16px;min-width:80px}}
 .card .n{{font-size:22px;font-weight:600}} .card .l{{font-size:12px;color:#57606a}}
 table{{border-collapse:collapse;width:100%;font-size:13px;margin-top:8px}}
 th,td{{border:1px solid #d0d7de;padding:6px 8px;text-align:left;vertical-align:top}}
 th{{background:#f6f8fa}} .badge{{color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600}}
 tr:hover{{background:#f6f8fa}}</style></head><body>
<h1>CIS Palo Alto Firewall Benchmark — Compliance Report</h1>
<div class="meta">Generated: {html.escape(meta['generated'])} &nbsp;|&nbsp;
 Benchmark: {html.escape(meta['benchmark'])} &nbsp;|&nbsp;
 Source: {html.escape(meta['source'])} &nbsp;|&nbsp; Devices: {len(devices)}</div>
<div class="cards">"""]
    for k in ["FAIL", "MANUAL", "ERROR", "PASS"]:
        b.append(f'<div class="card"><div class="n" style="color:{color[k]}">'
                 f'{s.get(k,0)}</div><div class="l">{k}</div></div>')
    b.append('</div><table><tr><th>Device</th><th>Control</th><th>Title</th>'
             '<th>Severity</th><th>Result</th><th>Evidence</th></tr>')
    for r in _sorted(rows):
        bg = color.get(r["result"], "#57606a")
        b.append(f"<tr><td>{html.escape(r['device'])}</td>"
                 f"<td>{html.escape(r['id'])}</td>"
                 f"<td>{html.escape(r['title'])}</td>"
                 f"<td>{html.escape(r['severity'])}</td>"
                 f"<td><span class='badge' style='background:{bg}'>{r['result']}</span></td>"
                 f"<td>{html.escape(r['evidence'])}</td></tr>")
    b.append('</table><p style="color:#57606a;font-size:11px;margin-top:16px">'
             'Self-generated assessment tool. Validate check logic against the CIS '
             'PAN-OS benchmark PDF before relying on this as sole audit evidence.</p>'
             '</body></html>')
    with open(p, "w") as f:
        f.write("".join(b))
    return p


def write_pdf(rows, out_dir, ts, meta):
    p = os.path.join(out_dir, f"cis_panos_report_{ts}.pdf")
    s = _summary(rows)
    meta_lines = [
        f"Generated: {meta['generated']}",
        f"Benchmark: {meta['benchmark']}",
        f"Source: {meta['source']}",
        f"Summary: FAIL={s.get('FAIL',0)}  MANUAL={s.get('MANUAL',0)}  "
        f"ERROR={s.get('ERROR',0)}  PASS={s.get('PASS',0)}",
    ]
    headers = ["Device", "Control", "Title", "Sev", "Result", "Evidence"]
    table = [(r["device"], r["id"], r["title"], r["severity"],
              r["result"], r["evidence"]) for r in _sorted(rows)]
    build_pdf(p, "CIS PAN-OS Compliance Report", meta_lines, table, headers)
    return p


# ----------------------------- main -----------------------------

def main():
    ap = argparse.ArgumentParser(description="CIS PAN-OS compliance audit tool")
    ap.add_argument("--target", choices=["panorama", "firewall"])
    ap.add_argument("--host")
    ap.add_argument("--apikey")
    ap.add_argument("--offline")
    ap.add_argument("--out", default="reports")
    ap.add_argument("--benchmark",
                    default="CIS Palo Alto Firewall Benchmark (latest)")
    ap.add_argument("--verify-tls", action="store_true")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    generated = datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")

    all_rows, source = [], ""

    if args.offline:
        source = f"offline export: {args.offline}"
        print(f"[*] Loading offline configs from {args.offline}")
        for label, cfg in load_offline_configs(args.offline):
            print(f"    - evaluating {label}")
            all_rows += run_checks(cfg, label)
    elif args.target == "firewall":
        if not (args.host and args.apikey):
            ap.error("--target firewall requires --host and --apikey")
        source = f"firewall {args.host}"
        print(f"[*] Pulling running config from firewall {args.host}")
        all_rows += run_checks(
            get_firewall_running_config(args.host, args.apikey, args.verify_tls),
            args.host)
    elif args.target == "panorama":
        if not (args.host and args.apikey):
            ap.error("--target panorama requires --host and --apikey")
        source = f"Panorama {args.host}"
        print(f"[*] Enumerating devices via Panorama {args.host}")
        devs = list_panorama_devices(args.host, args.apikey, args.verify_tls)
        print(f"    found {len(devs)} connected device(s)")
        for serial, hostname in devs:
            label = f"{hostname} ({serial})"
            print(f"    - pulling config: {label}")
            try:
                cfg = get_device_config_via_panorama(
                    args.host, args.apikey, serial, args.verify_tls)
                all_rows += run_checks(cfg, label)
            except Exception as e:
                all_rows.append({"device": label, "id": "-", "title": "config pull",
                                 "severity": "-", "result": "ERROR",
                                 "evidence": str(e)})
    else:
        ap.error("provide either --offline PATH or --target {panorama,firewall}")

    if not all_rows:
        raise SystemExit("No results produced.")

    meta = {"generated": generated, "benchmark": args.benchmark, "source": source}
    csv_p = write_csv(all_rows, args.out, ts)
    html_p = write_html(all_rows, args.out, ts, meta)
    pdf_p = write_pdf(all_rows, args.out, ts, meta)

    s = _summary(all_rows)
    print("\n=== Summary ===")
    print(f"  Devices : {len({r['device'] for r in all_rows})}")
    print(f"  PASS={s.get('PASS',0)}  FAIL={s.get('FAIL',0)}  "
          f"MANUAL={s.get('MANUAL',0)}  ERROR={s.get('ERROR',0)}")
    print(f"\nReports:\n  CSV : {csv_p}\n  HTML: {html_p}\n  PDF : {pdf_p}")


if __name__ == "__main__":
    main()

# CIS PAN-OS Compliance Audit Tool

Assess **Palo Alto firewalls** (Panorama-managed or standalone) against the
**CIS Palo Alto Firewall Benchmark** and produce timestamped **CSV + HTML + PDF**
reports suitable as audit evidence.

Built for the audit requests:
- **#54** — network compliance scan (the report)
- **#86** — annual config review (the report + your sign-off)
- **#87** — non-compliant population (filter the report to `result=FAIL`)

## Why this repo works in a locked-down environment

**Zero external dependencies.** Pure Python standard library — no `lxml`, no
`weasyprint`, nothing to `pip install`. If your org blocks package installs,
this still runs. Requires only **Python 3.8+** (already present on most systems).

Everything works out of the box. The **only** thing you provide is a read-only
API key (or exported config files).

## Repo structure
```
cis-panos-audit/
├── README.md
├── LICENSE
├── .gitignore
├── run.sh                     # convenience wrapper (offline demo)
├── export_configs.py          # pull configs from Panorama/firewall -> ./configs/
├── cis_panos/
│   ├── __init__.py
│   ├── audit.py               # main tool
│   ├── pdf_writer.py          # stdlib-only PDF generator
│   └── checks/
│       ├── __init__.py
│       └── cis_checks.py      # the CIS checks (extend here)
└── sample_configs/            # example good/bad configs to try immediately
    ├── fw01-good.xml
    └── fw02-bad.xml
```

## Quick start (no key needed — uses sample configs)
```bash
python3 -m cis_panos.audit --offline sample_configs/ --out reports/
```
Open the generated `reports/cis_panos_report_*.html` / `.pdf` / `.csv`.

## Get a read-only API key

1. On Panorama/firewall: **Device → Administrators → Add**, Administrator Type
   **Dynamic → Superreader** (read-only everywhere). Set a password.
2. Generate the key:
   ```bash
   curl -k "https://<host>/api/?type=keygen&user=<superreader_user>&password=<pass>"
   ```
   Copy the value inside `<key>...</key>`.

The tool only issues `show config` — it can never commit or change anything, and
superreader can't either. Two layers of read-only safety.

## Run against your firewalls

**Option A — Offline (recommended for banks):** export once, audit offline.
```bash
python3 export_configs.py --target panorama --host <PANO> --apikey "$KEY" --out ./configs/
python3 -m cis_panos.audit --offline ./configs/ --out reports/ \
    --benchmark "CIS Palo Alto Firewall 11 Benchmark v1.x"
```

**Option B — Live Panorama (all 32 devices at once):**
```bash
python3 -m cis_panos.audit --target panorama --host <PANO> --apikey "$KEY" --out reports/
```

**Option C — Single firewall:**
```bash
python3 -m cis_panos.audit --target firewall --host <FW> --apikey "$KEY" --out reports/
```

Set `--benchmark` to the exact CIS version you confirm you're assessing against;
it's printed on every report.

## Output
- `cis_panos_report_<ts>.csv` — sortable pass/fail (filter `result=FAIL` = #87)
- `cis_panos_report_<ts>.html` — readable summary + table
- `cis_panos_report_<ts>.pdf` — formal, timestamped evidence

Results: **PASS / FAIL / MANUAL / ERROR**. MANUAL = procedural control that can't
be scanned (e.g. "annual review performed") — cover with management sign-off.

## Extending checks
All checks live in `cis_panos/checks/cis_checks.py`. Each is a function returning
`(result, evidence)`; add an entry to the `CHECKS` list. The starter set covers
~14 automatable controls (password policy, mgmt hardening, HTTP/Telnet, SNMP, NTP,
TLS, logging, WildFire). The full CIS benchmark is ~150+ controls — extend
iteratively, validating each path against your CIS PDF and PAN-OS version.

## Read before using as audit evidence
1. **Validate every check against the CIS PDF** for your PAN-OS version.
2. **A self-built tool may be questioned by auditors** ("who validated the
   logic?"). Excellent for finding/fixing gaps and interim evidence; the durable
   control is a recognized tool — check if your org already owns **Firemon** (does
   PAN-OS CIS natively), **Tenable Nessus Pro**, or **Palo Alto BPA**.
3. Keep generated files unmodified; timestamps are the evidence.
4. Run against **all devices** — each firewall in an A/A or A/P pair is its own
   device with its own config. Panorama mode enumerates them automatically.

## License
MIT — see LICENSE.
